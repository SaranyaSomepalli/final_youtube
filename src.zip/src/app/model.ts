export interface videoData{
    id: number,
    videoTitle: string,
    channelName : string,
    thumbnailImage:string,
    channelIcon:string,
    views:string,
    duration:string,
    time:string
    
}